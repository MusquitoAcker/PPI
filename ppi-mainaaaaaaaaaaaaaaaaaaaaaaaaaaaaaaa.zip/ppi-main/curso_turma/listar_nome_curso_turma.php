<?php 
    if($_SESSION["categoria"] != 3){

            # consulta ao nome do curso na tabela curso
            $sql_curso = "SELECT id_curso, nome FROM curso
            ORDER BY nome ASC";
            $res_curso = $conexao->query($sql_curso);
            $qtd_curso = $res_curso->num_rows;

            
            if($qtd_curso>0){
                
                
                while($row_curso = $res_curso->fetch_object()){
                    echo "<div class='container_curso_geral'>";
                    echo "<div class='container_titulo_curso'>";
                    echo "<div class='titulo_curso'>";
                    echo $row_curso->nome;
                    echo "</div>";
                    
                    if($_SESSION["categoria"]==1 || $_SESSION["categoria"]==2){
                        echo " <button class='botao_editar_curso1' onclick=\"location.href='?page=editar_curso&id=" . $row_curso->id_curso . "';\"><i class='bi bi-pen-fill'></i></button>";
                        echo " <button class='botao_excluir_curso' onclick=\"if(confirm('Tem certeza que deseja excluir?')){location.href='?page=salvar_curso&acao=excluir&id=".$row_curso->id_curso."';}else{false;}\"'><i class='bi bi-trash3-fill'></i></button><br>";
                    }
                    else{
                        echo "<br>";
                    }

                    echo "</div>";

                    #consulta ao numero da turma na tabela turma
                    $sql_turma = "SELECT id_turma, numero, id_curso FROM turma
                    ORDER BY NUMERO ASC ";

                    $res_turma = $conexao->query($sql_turma);

                    $qtd_turma = $res_turma->num_rows;


                    if($qtd_turma>0){
                        echo "<div class='container_turmas'>";
                        while($row_turma = $res_turma->fetch_object()){
                            
                            
                            if($row_turma->id_curso == $row_curso->id_curso){
                                echo "<div class='turma_div'>";
                                echo "<button class='botao_turma ' onclick=\"location.href='?page=turma&idturma=" . $row_turma->id_turma . "';\"> Turma ". $row_turma->numero ."</button>";
                                if($_SESSION["categoria"]==1 || $_SESSION["categoria"]==2){
                                    echo "<button class='editar_turma' onclick=\"location.href='?page=editar_turma&idturma=" . $row_turma->id_turma . "&r=cursoturma';\"><i class='bi bi-pen-fill'></i></button>";
                                    echo " <button class='excluir_turma' onclick=\"if(confirm('Tem certeza que deseja excluir?')){location.href='?page=salvar_turma&acao=excluir&idturma=".$row_turma->id_turma."';}else{false;}\"'><i class='bi bi-trash3-fill'></i></button><br>";
                                }
                                else{
                                    echo "<br>";
                                }
                                echo "</div>";
                            }
                            
                        }
                        echo "</div>";

                    }
                    echo "</div>";
                
                }

            }

            
    }

    else {
        // Consulta que une as tabelas turma e disciplina para evitar a necessidade de múltiplas consultas e loops.
        $sql_turma_disciplina = "
            SELECT curso.nome AS nome_curso, turma.numero, disciplina.nome, disciplina.id_disciplina, turma.id_turma 
            FROM turma
            INNER JOIN curso ON turma.id_curso = curso.id_curso 
            INNER JOIN disciplina ON turma.id_turma = disciplina.id_turma 
            WHERE disciplina.id_professor = " . $_SESSION["id_usuario"];
    
        $res_turma_disciplina = $conexao->query($sql_turma_disciplina);
        $qtd_turma_disciplina = $res_turma_disciplina->num_rows;
    
        if ($qtd_turma_disciplina > 0) {
            while ($row_turma_disciplina = $res_turma_disciplina->fetch_object()) {
                // Exibe o número da turma e o nome da disciplina.
                echo $row_turma_disciplina->nome_curso . "<br>";
                echo "<button onclick=\"location.href='?page=turma&idturma=" . $row_turma_disciplina->id_turma . "&iddisciplina=".$row_turma_disciplina->id_disciplina ."';\"> Turma ". $row_turma_disciplina->numero . " - " . $row_turma_disciplina->nome . "</button> <br>";
            }
        } else {
            echo "Nenhuma turma encontrada para este professor.";
        }
    }
    

?>