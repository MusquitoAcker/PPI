<?php 
    $sql = "SELECT * FROM categoria
    ORDER BY id_categoria";

    $res= $conexao->query($sql);

    $qtd = $res->num_rows;
?>

<div class='gerenciar_usuarios_titulo'>Adicionar Usuários</div>

<form action="?page=salvar&acao=cadastrar" method="POST"> 
    <div class='quadrado_branco_cadastrar_usuarios'>

        <div>
            <label class='texto_cadastrar1'>Nome</label> 
            <input class='formulario_cadastrar1' type="text" name="nome" required> 
        </div>
        <div>
            <label class='texto_cadastrar2'>E-Mail</label> 
            <input class='formulario_cadastrar2' type="email" name="email" required> 
        </div>
        <div class='container_opcoes_categoria'>
            <label class='texto_cadastrar3'>Categoria<br></label>
            <div class='opcoes_categoria'>
                <?php 
                    if($qtd>0){
                        while($row=$res->fetch_object()){
                                echo "<input type=\"radio\" name=\"categoria\" value=\"".$row->id_categoria."\" required>";
                                echo "<label for=\"categoria\">".$row->categoria."</label><br>";
                        }
                    }
                ?>
            </div>

        </div>
        <div>
            <button class='botao_adicionar_usuario_pg_usuario' type="submit">Adicionar</button>
        </div>

    </div>
</form>