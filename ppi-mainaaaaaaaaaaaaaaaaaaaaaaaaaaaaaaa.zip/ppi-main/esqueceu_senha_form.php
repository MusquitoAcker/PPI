<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nexum</title>
    <link rel="stylesheet" href="./assets/pag_login.css">
</head>
<body>
    <h1 class="titulo_email_req_senha">Recuperar a Senha</h1>
    <div class="retangulo_conteudo_req_senha">
        <form action="esqueceu_senha_email.php" method="POST">
            <div>
                <label class="email_esq_senha">E-mail</label>
                <input class="caixa_email_esqu_senha" type="e-mail" name="email">
            </div>
            <div>
                <button class="botao_enviar_email_req" type="submit">Enviar</button>
            </div>
        </form>
    </div>
</body>
</html>