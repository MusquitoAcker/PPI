<div class='caixa_branco_conteudo_cadastrar'>


<div class='gerenciar_parecer_titulo'>Editar Parecer</div>
<?php
    //consulta para pegar os dados necessários
     $sql = "SELECT * FROM parecer WHERE id_parecer = " . $_REQUEST["idparecer"];
     $res = $conexao->query($sql);
     $row=$res->fetch_object();
     $qtd = $res->num_rows;


     if($qtd>0){
        echo "<form enctype=\"multipart/form-data\" action=\"?page=salvar&acao=editar&idparecer=". $_REQUEST["idparecer"] ."\" method=\"POST\">";

            echo "<div class='parte_escrita'>Texto</label><div>";
            echo "<textarea name=\"texto_parecer\">". $row->texto."</textarea><br><br>";

            echo "<label>Imagem</label><br>";
            if($row->imagem != NULL){
                echo "<br>Imagem atual";
                echo "<br><img src=\"../gerenciar_parecer/imagem_parecer/". $row->imagem."\"/><br>";
                echo "<input type=\"hidden\" value=\"". $row->imagem."\" name=\"imagem_antiga\">";

                echo "Nova Imagem <br>";
                echo "<input type=\"file\" name=\"imagem_nova\"><br><br>";
            }
            else{
                echo "<input type=\"file\" name=\"imagem\"><br><br>";
            }

            echo "<div class='container_contatos'>";
            echo "<div class='titulos_cargos_pareceres'>Contato Direção de Ensino</div> <br> ";
            echo "<label>Nome do Diretor(a) de Ensino</label> <br>";
            echo "<input type='text' name=\"nome_diretor_ensino\" value=\"".$row->nome_diretor_ensino."\"><br><br>";
            echo "<label>E-mail da Direção</label> <br>";
            echo "<input type='email' name=\"email_diretor_ensino\" value=\"".$row->email_diretor_ensino."\">";
            echo "<br><br>";
            echo "</div>";

            echo "<div class='container_contatos'>";
            echo "<div class='titulos_cargos_pareceres'>Contato Coordenação de Ensino</div> <br>";
            echo "<label>Nome do Coordenador(a) de Ensino</label> <br>";
            echo "<input type='text' name=\"nome_coor_ensino\" value=\"".$row->nome_coor_ensino."\"><br><br>";
            echo "<label>E-mail da Coordenação</label> <br>";
            echo "<input type='email' name=\"email_coor_ensino\" value=\"".$row->email_coor_ensino."\">";
            echo "<br><br>";
            echo "</div>";

            echo "<div class='container_contatos'>";
            echo "<div class='titulos_cargos_pareceres'>Contato Coordenação de Assistência Estudantil</div> <br>";
            echo "<label>Nome do Coordenador(a)</label> <br>";
            echo "<input type='text' name=\"nome_coor_cae\" value=\"".$row->nome_coor_cae."\"><br><br>";
            echo "<label>E-mail da Coordenação</label> <br>";
            echo "<input type='email' name=\"email_coor_cae\" value=\"".$row->email_coor_cae."\">";
            echo "<br><br>";
            echo "</div>";

            echo "<button class='botao_cadastrar' type=\"submit\">Salvar</button>";
        }
?>

</div>