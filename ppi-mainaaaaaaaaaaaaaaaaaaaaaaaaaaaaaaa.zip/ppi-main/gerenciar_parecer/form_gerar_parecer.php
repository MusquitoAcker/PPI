   <?php 
     include ("../config.php");
     #consulta a tabela turma
     $sql_turma = "SELECT id_turma, numero FROM turma
                     ORDER BY numero ASC";

     $res_turma = $conexao->query($sql_turma);
     $qtd_turma = $res_turma->num_rows;

     #consulta a tabela turma
     $sql_aluno = "SELECT id_aluno, nome FROM aluno
                     ORDER BY nome ASC";

     $res_aluno = $conexao->query($sql_aluno);
     $qtd_aluno = $res_aluno->num_rows;
   
   ?>
                    <form action="./gerar_parecer.php" method="POST">
                        <br>
                        <label>Turma</label>
                        <select name="turma">
                                <option value=" " selected> </option>;
                                <?php
                                        if($qtd_turma>0){
                                            while($row_turma = $res_turma->fetch_object()){
                                                echo "<option value=\"". $row_turma->id_turma."\">". $row_turma->numero ."</option>";
                                            }
                                        }  
                                ?>
                            </select>
        
                        <br><br> 
                        Para gerar o parecer de um aluno específico:
                        
                            <select name="aluno">
                                <option value=" " selected> </option>;
                                <?php
                                        if($qtd_aluno>0){
                                            while($row_aluno = $res_aluno->fetch_object()){
                                                echo "<option value=\"". $row_aluno->id_aluno."\">". $row_aluno->nome ."</option>";
                                            }
                                        }  
                                ?>
                            </select><br><br>
        
                            <button type="submit">Gerar Pareceres</button>
                    </form>
        
                