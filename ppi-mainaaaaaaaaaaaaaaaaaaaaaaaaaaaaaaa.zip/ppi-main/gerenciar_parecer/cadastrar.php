<div class='caixa_branco_conteudo_cadastrar'>
    <div class='gerenciar_parecer_titulo'>Parecer</div> 
            <form enctype="multipart/form-data" action="?page=salvar&acao=cadastrar" method="POST">
                <div>
                    <div class='parte_escrita'>Texto do Parecer</div> 
                    <textarea name="texto_parecer" required></textarea>
                    <br> <br>
                <div>
                
                <div>
                    <label>Imagem</label> 
                    <input type='file' name="imagem">
                    <br> <br>
                </div>

                <div class='container_contatos'>
                    <div class='titulos_cargos_pareceres'>Contato Direção de Ensino</div> <br>

                    <label>Nome do Diretor(a) de Ensino</label> <br>
                    <input type='text' name="nome_diretor_ensino">
                    <br><br>
                    <label>E-mail da Direção</label> <br>
                    <input type='email' name="email_diretor_ensino">
                    <br><br>
                </div>

                <div class='container_contatos'>
                    <div class='titulos_cargos_pareceres'>Contato Coordenação de Ensino</div>  <br>

                    <label>Nome do Coordenador(a) de Ensino</label> <br>
                    <input type='text' name="nome_coor_ensino">
                    <br><br>

                    <label>E-mail da Coordenação</label> <br>
                    <input type='email' name="email_coor_ensino">
                    <br><br>
                </div>

                <div class='container_contatos'>
                    <div class='titulos_cargos_pareceres'>Contato Coordenação de Assitência Estudantil</div>  <br>

                    <label>Nome do Coordenador(a)</label> <br>
                    <input type='text' name="nome_coor_cae">
                    <br><br>

                    <label>E-mail da Coordenação</label> <br> 
                    <input type='email' name="email_coor_cae">
                    <br><br>
                </div>

                <button class='botao_cadastrar' type="submit">Cadastrar</button>

            </form>
</div>