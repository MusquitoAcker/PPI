<?php 

switch ($_REQUEST["acao"]) {
    case 'cadastrar':
        $id_disciplina = $_REQUEST["iddisciplina"];
        $observacao = $_POST["observacao"];
        $id_aluno = $_REQUEST["idaluno"];

        // verifica no banco se o aluno já está cadastrado na disciplina
        $sql_verifica = "SELECT * FROM aluno_disciplina
                        WHERE id_aluno = ".$id_aluno." AND id_disciplina = " . $id_disciplina;
        $res_verifica = $conexao->query($sql_verifica);

        if($res_verifica->num_rows > 0){
            $observacao = $_POST["observacao"];

            //atualiza no banco
            $sql_observacao = "UPDATE aluno_disciplina
                                SET observacao = '{$observacao}'
                                WHERE id_aluno = ".$id_aluno." AND id_disciplina = " . $id_disciplina;
            
            $res_observacao= $conexao->query($sql_observacao);

            if($res_observacao == true){
                echo "<script>alert('Cadastrado com sucesso!');</script>";
                echo "<script>location.href='?page=aluno&info=listar_observacoes_aluno&idaluno=".  $_REQUEST["idaluno"] ."&idturma=" .  $_REQUEST["idturma"] . "&iddisciplina=" . $_REQUEST["iddisciplina"] . "';</script>";
            }

            else{
                echo "<script>alert('Não foi possível editar!');</script>";
                echo "<script>location.href='?page=aluno&info=listar_observacoes_aluno&idaluno=".  $_REQUEST["idaluno"] ."&idturma=" .  $_REQUEST["idturma"] . "&iddisciplina=" . $_REQUEST["iddisciplina"] . "';</script>";
            }

        }
        else{

            // insere no banco
            $sql_observacao = "INSERT INTO aluno_disciplina (id_aluno, id_disciplina, observacao)
                                VALUES ('{$id_aluno}', '{$id_disciplina}', '{$observacao}')";

            $res_observacao= $conexao->query($sql_observacao);

            if($res_observacao == true){
                echo "<script>alert('Cadastrado com sucesso!');</script>";
                echo "<script>location.href='?page=aluno&info=listar_observacoes_aluno&idaluno=".  $_REQUEST["idaluno"] ."&idturma=" .  $_REQUEST["idturma"] . "&iddisciplina=" . $_REQUEST["iddisciplina"] . "';</script>";
            }

            else{
                echo "<script>alert('Não foi possível cadastrar!');</script>";
                echo "<script>location.href='?page=aluno&info=listar_observacoes_aluno&idaluno=".  $_REQUEST["idaluno"] ."&idturma=" .  $_REQUEST["idturma"] . "&iddisciplina=" . $_REQUEST["iddisciplina"] . "';</script>";
            }
        }
        break;

    case 'editar':
        $observacao = $_POST["observacao"];

            //atualiza no banco
            $sql_observacao = "UPDATE aluno_disciplina
                                SET observacao = '{$observacao}'
                                WHERE id_aluno_disciplina = ".$_REQUEST["idalunodisciplina"];
            
            $res_observacao= $conexao->query($sql_observacao);

            if($res_observacao == true){
                echo "<script>alert('Editado com sucesso!');</script>";
                echo "<script>location.href='?page=aluno&info=listar_observacoes_aluno&idaluno=".  $_REQUEST["idaluno"] ."&idturma=" .  $_REQUEST["idturma"] . "&iddisciplina=" . $_REQUEST["iddisciplina"] . "';</script>";
            }

            else{
                echo "<script>alert('Não foi possível editar!');</script>";
                echo "<script>location.href='?page=aluno&info=listar_observacoes_aluno&idaluno=".  $_REQUEST["idaluno"] ."&idturma=" .  $_REQUEST["idturma"] . "&iddisciplina=" . $_REQUEST["iddisciplina"] . "';</script>";
            }
            
        break;

    case 'excluir':
        
        $observacao = NULL;
        $sql_observacao = "UPDATE aluno_disciplina
                            SET observacao = '{$observacao}'
                            WHERE id_aluno_disciplina = " . $_REQUEST["idalunodisciplina"];
        
        $res_observacao= $conexao->query($sql_observacao);

        if($res_observacao == true){
            echo "<script>alert('Excluído com sucesso!');</script>";
            echo "<script>location.href='?page=aluno&info=listar_observacoes_aluno&idaluno=".  $_REQUEST["idaluno"] ."&idturma=" .  $_REQUEST["idturma"] . "&iddisciplina=" . $_REQUEST["iddisciplina"] . "';</script>";
        }

        else{
            echo "<script>alert('Não foi possível excluir!');</script>";
            echo "<script>location.href='?page=aluno&info=listar_observacoes_aluno&idaluno=".  $_REQUEST["idaluno"] ."&idturma=" .  $_REQUEST["idturma"] . "&iddisciplina=" . $_REQUEST["iddisciplina"] . "';</script>";
        }
        break;
        
}

?>