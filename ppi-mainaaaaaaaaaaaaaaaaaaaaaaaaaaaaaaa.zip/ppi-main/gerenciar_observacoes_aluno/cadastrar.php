<h1>Registrar Observação</h1>
<form action="?page=aluno&info=salvar_observacoes_aluno&acao=cadastrar&idturma=<?php echo $_REQUEST["idturma"];?>&iddisciplina=<?php echo $_REQUEST["iddisciplina"];?>&idaluno=<?php echo $_REQUEST["idaluno"]?>" method="POST">
    <div>
        <label>Observação</label>
        <textarea name="observacao" required></textarea>
    </div>
    <div>
        <button type="submit">Adicionar</button>
    </div>
</form>