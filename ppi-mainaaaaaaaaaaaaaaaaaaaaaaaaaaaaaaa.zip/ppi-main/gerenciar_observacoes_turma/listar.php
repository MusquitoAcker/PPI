<h1>Observações sobre a Turma</h1>
<?php 
    // selecionar no banco as observações existentes e listá-las
    $sql_disciplina = "SELECT disciplina.id_disciplina, disciplina.nome, disciplina.id_professor, observacoes.id_observacao, observacoes.observacao 
                    FROM disciplina INNER JOIN observacoes
                    ON disciplina.id_disciplina = observacoes.id_disciplina
                    WHERE observacoes.id_turma = " . $_REQUEST["idturma"];

    $res_disciplina = $conexao->query($sql_disciplina);
    $qtd_disciplina = $res_disciplina->num_rows;

    //opções de criar nova observação
    if($_SESSION["categoria"]==3){
        echo "<button onclick=\"location.href='?page=cadastrar_observacoes_turma&idturma=".$_REQUEST["idturma"]."&iddisciplina=" . $_REQUEST["iddisciplina"] . "';\">Cadastrar Observação</button>";
    }   

    // lista as observacoes existentes no bd
    if($qtd_disciplina>0){
        while ($row_disciplina = $res_disciplina->fetch_object()) {
                echo "<div>";

                    echo $row_disciplina->nome . "<br>";
                    echo $row_disciplina->observacao . "<br><br>";

                    if ($row_disciplina->id_professor == $_SESSION["id_usuario"]) {

                        echo "<button onclick=\"location.href='?page=editar_observacoes_turma&idturma=".$_REQUEST["idturma"]."&iddisciplina=" . $row_disciplina->id_disciplina ."&idobservacao=".$row_disciplina->id_observacao."';\">Editar</button>";

                        echo " <button onclick=\"if(confirm('Tem certeza que deseja excluir?')){location.href='?page=salvar_observacoes_turma&acao=excluir&&idturma=".$_REQUEST["idturma"]."&iddisciplina=".$row_disciplina->id_disciplina ."&idobservacao=".$row_disciplina->id_observacao."';}else{false;}\"'>Excluir</button><br>";
                    }

                echo "</div>";
            }

        }

?>