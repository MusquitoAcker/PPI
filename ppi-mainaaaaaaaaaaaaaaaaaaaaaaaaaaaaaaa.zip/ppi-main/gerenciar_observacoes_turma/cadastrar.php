<h1>Registrar Observação</h1>
<form action="?page=salvar_observacoes_turma&acao=cadastrar&idturma=<?php echo $_REQUEST["idturma"];?>&iddisciplina=<?php echo $_REQUEST["iddisciplina"];?>" method="POST">
    <div>
        <label>Observação</label>
        <textarea name="observacao" required></textarea>
    </div>
    <div>
        <button type="submit">Salvar</button>
    </div>
</form>