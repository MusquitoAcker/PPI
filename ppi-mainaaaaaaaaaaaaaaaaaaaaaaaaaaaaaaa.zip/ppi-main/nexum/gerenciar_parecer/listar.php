<?php 
    $sql = "SELECT * FROM parecer";
    
    $res = $conexao->query($sql);
    $qtd = $res->num_rows;

    if($qtd>0){
        while($row = $res->fetch_object()){
            echo "<div class='descricao'>";
            echo "<p>" . $row->texto . "</p>";
            echo "</div>";

            echo "<img class='imagem_parecer' src=\"../gerenciar_parecer/imagem_parecer/". $row->imagem."\"/>";

            echo "<br><br> <div class='texto_contatos'> Contatos: </div> <br>";

            echo "<div class='container_contatos'>";
            echo "<div class='titulos_cargos_pareceres'> Direção de Ensino </div>";
            echo "<div class='texto_cargos'>";
            echo $row->nome_diretor_ensino;
            echo "<br>Contato: " . $row->email_diretor_ensino . "<br>";
            echo "</div>";
            echo "</div>";

            echo "<div class='container_contatos'>";
            echo "<div class='titulos_cargos_pareceres' >Coordenação Geral de Ensino </div>";
            echo "<div class='texto_cargos'>";
            echo $row->nome_coor_ensino;
            echo "<br>Contato: " . $row->email_coor_ensino . "<br>";
            echo "</div>";
            echo "</div>";

            echo "<div class='container_contatos'>";
            echo "<div class='titulos_cargos_pareceres'>Coordenação de Assistência Estudantil </div>";
            echo "<div class='texto_cargos'>";
            echo $row->nome_coor_cae;
            echo "<br>Contato: " . $row->email_coor_cae . "<br>";
            echo "</div>";
            echo "</div>";

            echo "<button class='botao_editar' onclick=\"location.href='?page=editar_texto&idparecer=" . $row->id_parecer . "';\">Editar</button>";
            echo " <button class='botao_excluir' onclick=\"if(confirm('Tem certeza que deseja excluir?')){location.href='?page=salvar&acao=excluir&idparecer=" . $row->id_parecer . "';}else{false;}\"'>Excluir</button><br>";
        }
    }
    else{
        echo "<br> Não há parecer cadastrado <br> <br>";
        echo "<a class='texto_sem_parecer' href=\"?page=cadastrar_texto\">Cadastrar Texto</a> <br> <br>"; 
        echo "<div class='gerenciar_parecer_titulo'>Parecer</div>";
        
    }

?>