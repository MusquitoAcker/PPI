<?php 
    $sql_observacao = "SELECT id_observacao, observacao FROM observacoes WHERE id_observacao=".$_REQUEST["idobservacao"];
    $res_observacao = $conexao->query($sql_observacao);
    $row_observacao = $res_observacao->fetch_object();
?>

<div class='listar_observacoes_turma_titulo'>Editar Observação</div>

<div class="container_observacoes_turma">
    <form action="?page=salvar_observacoes_turma&acao=editar&idturma=<?php echo $_REQUEST["idturma"];?>&iddisciplina=<?php echo $_REQUEST["iddisciplina"];?>&idobservacao=<?php echo $_REQUEST["idobservacao"];?>" method="POST">
        <div>
            <label>Observação</label> <br>
            <textarea class='caixa_editar_observacao' name="observacao"><?php echo $row_observacao->observacao;?></textarea>
        </div>
        <div>
            <button class='botao_editar_observacao_turma' type="submit">Salvar</button>
        </div>
    </form>
</div>