<h2>Relatórios de Recuperação Paralela</h2>
<?php 

    if($_SESSION["categoria"]==3){
        // fazer aqui abaixo a consulta com os nomes dos arquivos para a disciplina em questão

        // consulta na turma
        $sql_turma = "SELECT numero
                FROM turma
                WHERE id_turma=" . $_REQUEST["idturma"];

        $res_turma = $conexao->query($sql_turma);
        $row_turma = $res_turma->fetch_object();

        // consulta na disciplina
        $sql_disciplina = "SELECT nome, recuperacao_paralela1, recuperacao_paralela2
                FROM disciplina
                WHERE id_disciplina=" . $_REQUEST["iddisciplina"];

        $res_disciplina = $conexao->query($sql_disciplina);
        $row_disciplina = $res_disciplina->fetch_object();


        echo "<button onclick=\"location.href='?page=enviar_recuperacao_paralela&idturma=" . $_REQUEST["idturma"] . "&iddisciplina=" . $_REQUEST["iddisciplina"] . "&nomedisciplina=". $row_disciplina->nome."&numeroturma=". $row_turma->numero."';\">Enviar Relatório</button>";

        if($row_disciplina->recuperacao_paralela1 != NULL){
        // listar as recuperações paralelas
           echo "<br><br><a href=\"../recuperacao_paralela/".$row_disciplina->recuperacao_paralela1."\" download=\"".$row_disciplina->recuperacao_paralela1."\">".$row_disciplina->recuperacao_paralela1."</a>";
        }
        if($row_disciplina->recuperacao_paralela2 != NULL){
            // listar as recuperações paralelas
               echo "<br><br><a href=\"../recuperacao_paralela/".$row_disciplina->recuperacao_paralela2."\" download=\"".$row_disciplina->recuperacao_paralela2."\">".$row_disciplina->recuperacao_paralela2."</a>";
        }

    }
    else{
        //consulta na tabela da recuperação paralela
        // consulta na disciplina
        $sql_disciplina = "SELECT recuperacao_paralela1, recuperacao_paralela2
                FROM disciplina
                WHERE id_turma=" . $_REQUEST["idturma"];

        $res_disciplina = $conexao->query($sql_disciplina);

        // listar as recuperações paralelas da turma
        while($row_disciplina = $res_disciplina->fetch_object()){
            if($row_disciplina->recuperacao_paralela1 != NULL){
                // listar as recuperações paralelas
                   echo "<br><br><a href=\"../recuperacao_paralela/".$row_disciplina->recuperacao_paralela1."\" download=\"".$row_disciplina->recuperacao_paralela1."\">".$row_disciplina->recuperacao_paralela1."</a>";
                }
                if($row_disciplina->recuperacao_paralela2 != NULL){
                    // listar as recuperações paralelas
                       echo "<br><br><a href=\"../recuperacao_paralela/".$row_disciplina->recuperacao_paralela2."\" download=\"".$row_disciplina->recuperacao_paralela2."\">".$row_disciplina->recuperacao_paralela2."</a>";
                }
         }

    }
?>
