</div>

<?php 
    $sql_observacao = "SELECT id_aluno_disciplina, observacao FROM aluno_disciplina WHERE id_aluno_disciplina=".$_REQUEST["idalunodisciplina"];
    $res_observacao = $conexao->query($sql_observacao);
    $row_observacao = $res_observacao->fetch_object();
?>


  <div class='listar_observacoes_turma_titulo'>Editar Observação</div>

<div class="container_observacoes_turma">
    <form action="?page=aluno&info=salvar_observacoes_aluno&acao=editar&idturma=<?php echo $_REQUEST["idturma"];?>&iddisciplina=<?php echo $_REQUEST["iddisciplina"];?>&idaluno=<?php echo $_REQUEST["idaluno"]?>&idalunodisciplina=<?php echo $_REQUEST["idalunodisciplina"];?>" method="POST">
        <div>
            <label>Observação</label> <br>
            <textarea class='caixa_editar_observacao' name="observacao"><?php echo $row_observacao->observacao;?></textarea>
        </div>
        <div>
            <button class='botao_editar_observacao_turma' type="submit">Salvar</button>
        </div>
    </form>

<script>

    document.addEventListener("DOMContentLoaded", () => {
        const container = document.querySelector('.container_info_aluno');

        function checkAndHideContainer() {
            // Verifica se o conteúdo do container está vazio ou contém apenas espaços em branco
            if (!container.textContent.trim()) {
                container.style.display = 'none';
            } else {
                container.style.display = 'block'; // Garante que o container fique visível se houver conteúdo
            }
        }

        // Verifica inicialmente quando a página é carregada
        checkAndHideContainer();

        // Caso o conteúdo seja atualizado dinamicamente, pode-se usar um MutationObserver
        const observer = new MutationObserver(() => {
            checkAndHideContainer();
        });

        // Observa mudanças no conteúdo do container
        observer.observe(container, { childList: true, subtree: true });
    });


</script>
</div>