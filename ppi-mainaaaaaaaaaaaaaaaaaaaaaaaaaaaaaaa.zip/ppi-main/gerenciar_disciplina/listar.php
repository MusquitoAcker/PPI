<?php 
    $sql_turma_disciplina = "SELECT turma.numero, disciplina.nome, disciplina.id_disciplina, disciplina.id_turma
                            FROM turma, disciplina
                            WHERE turma.id_turma = disciplina.id_turma
                            ORDER BY turma.numero";
    
    $res_turma_disciplina = $conexao->query($sql_turma_disciplina);
    $qtd_turma_disciplina = $res_turma_disciplina->num_rows;
    if($qtd_turma_disciplina>0){
        
        while($row_turma_disciplina = $res_turma_disciplina->fetch_object()){
            echo "<div class='caixa_diciplinas'>";
                echo "<div class='texto_diciplina'>";
                    echo "Turma ". $row_turma_disciplina->numero . " - ".$row_turma_disciplina->nome;
                echo "</div>";
                echo "<button class='botao_editar' onclick=\"location.href='?page=editar&iddisciplina=" . $row_turma_disciplina->id_disciplina . "&idturma=". $row_turma_disciplina->id_turma ."';\"><i class='bi bi-pen-fill'></i></button>";
                echo " <button class='botao_excluir'  onclick=\"if(confirm('Tem certeza que deseja excluir?')){location.href='?page=salvar&acao=excluir&iddisciplina=".$row_turma_disciplina->id_disciplina."';}else{false;}\"'> <i class='bi bi-trash3-fill'> </i> </button>";
            echo "</div>";
        }
        
    }

?>