<div class='gerenciar_diciplinas_titulo'>Editar Disciplina</div>
<?php
    #consulta a tabela turma
    $sql_turma = "SELECT id_turma, numero FROM turma
                ORDER BY numero";

    $res_turma = $conexao->query($sql_turma);
    $qtd_turma = $res_turma->num_rows;

    #consulta a tabela usuario
    $sql_usuario = "SELECT id_usuario, nome FROM usuario 
                    WHERE categoria = 3
                    ORDER BY nome ASC";

    $res_usuario = $conexao->query($sql_usuario);
    $qtd_usuario = $res_usuario->num_rows;

    #consulta a tabela disciplina
    $sql_disciplina = "SELECT id_disciplina, nome, quant_periodos, id_turma, id_professor FROM disciplina 
                    WHERE id_disciplina =" . $_REQUEST["iddisciplina"];

    $res_disciplina = $conexao->query($sql_disciplina);
    $row_disciplina = $res_disciplina->fetch_object();

?>
    <div class='quadrado_branco_editar'>
        <form action="?page=salvar&acao=editar&iddisciplina=<?php echo $_REQUEST["iddisciplina"];?>" method="POST">
            
            <div>
                <label class='texto_editar1'>Disciplina</label>
                <input class='tabela_editar1' type="text" name="disciplina" value="<?php echo $row_disciplina->nome?>" required>
            </div>

            <div>
                <label class='texto_editar2'>Quantidade de Períodos</label>
                <input class='tabela_editar2' type="number" name="quant_periodos" value="<?php echo $row_disciplina->quant_periodos?>" required>
            </div>

            <div>
                <label class='texto_editar3'>Professor</label>
                <select class='tabela_editar3' name="professor">
                    <?php
                        if($qtd_usuario>0){
                            while($row_usuario = $res_usuario->fetch_object()){
                                if($row_disciplina->id_professor == $row_usuario->id_usuario){
                                    echo "<option value=\"". $row_usuario->id_usuario."\" selected>". $row_usuario->nome ."</option>";
                                }
                                else{
                                    echo "<option value=\"". $row_usuario->id_usuario."\">". $row_usuario->nome ."</option>";
                                }
                            }
                        }  
                    ?>
                </select>
            </div>

            <div>
                <label class='texto_editar4'>Turma</label>
                <div class='container_turma'>
                        <?php
                            if($qtd_turma>0){
                                while($row_turma = $res_turma->fetch_object()){
                                    if($row_disciplina->id_turma == $row_turma->id_turma){
                                        echo "<input type=\"radio\" name=\"turma\" value=\"".$row_turma->id_turma."\" checked>";
                                        echo "<label for=\"turma\">T".$row_turma->numero."</label><br>";
                                    }
                                    else{
                                        echo "<input type=\"radio\" name=\"turma\" value=\"".$row_turma->id_turma."\">";
                                        echo "<label for=\"turma\">T".$row_turma->numero."</label><br>";
                                    }
                                }
                            }  
                        ?>
                </div>

            </div>
            <div>
                <button class='botao_salvar_edicao' type="submit">Salvar</button>
            </div>
        </form>
    </div>