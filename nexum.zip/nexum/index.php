<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./assets/pag_login.css">
    <title>Login - Nexum</title>
</head>
<body>
    <div class="retangulo_conteudo">
        <div class="titulo_login">Login</div>
        <div>
            <img class="logo_if" src="./assets/imagens/if.png" alt="Logo IF">
        </div>
        <form action="login.php" method="POST">
            <div>
                <label class="texto_email">E-Mail</label> <br>
                <input type="e-mail" name="email" class="caixa_email">
            </div>
            <div>
                <label class="texto_senha">Senha</label>
                <input class="caixa_senha" type="password" name="senha">
            </div>
            <div>
                <button class="botao_enviar" type="submit">Enviar</button>
            </div>
        </form>
        <a class="esqueceu_senha_botao" href="esqueceu_senha_form.php">Esqueceu a senha?</a>
    </div>
</body>
</html>