<?php 
    require_once('./src/PHPMailer.php');
    require_once('./src/SMTP.php');
    require_once('./src/Exception.php');

    include("./config.php");

    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\SMTP;
    use PHPMailer\PHPMailer\Exception;

    $mail = new PHPMailer(true);

    try {
        $email = $_POST["email"];

        $token = bin2hex(random_bytes(32));
        $expira_em = date('Y-m-d H:i:s', strtotime('+1 hour'));

        // $sql = "INSERT INTO recuperacao_senha (email, token, expira_em) VALUES ('{$email}', '{$token}', '{$expira_em}')";
        // $res = $conexao->query($sql);

        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'nexum.inf@gmail.com';
        $mail->Password = 'tlojntypjtymyczs';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('nexum.inf@gmail.com');
        $mail->addAddress($email);

        $mail->CharSet = 'UTF-8';
        $link = "http://localhost:8080/nexum/recuperar_senha_form.php?token=$token";

        $mail->isHTML(true);
        $mail->Subject = 'Recuperação de Senha';
        $mail->Body = "Para recuperar sua senha, acesse o link abaixo:<br><a href='$link'>$link</a>";
        $mail->AltBody = "Para recuperar sua senha, acesse o link: $link";

        if($mail->send()){
            echo "<script>alert('E-mail enviado com sucesso!');</script>";
            echo "<script>location.href='./index.php';</script>";
        }

    } catch(Exception $e){
        echo "<script>alert('Erro ao enviar e-mail!');</script>";
        echo "<script>location.href='./index.php';</script>";
    }
?>
