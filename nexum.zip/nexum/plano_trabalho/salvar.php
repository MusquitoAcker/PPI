<?php 
    $id_professor= $_REQUEST["idusuario"];
    $semestre = $_POST["semestre"];
    $ano = $_POST["ano"];
    $arquivo = $_FILES["rel_plano"];

    //consulta para pegar o nome do professor
    $sql_nome = "SELECT nome FROM usuario WHERE id_usuario = " . $id_professor;
    $res_nome = $conexao->query($sql_nome);
    $row_nome = $res_nome->fetch_object();

    if (!preg_match("/^application\/pdf$/", $arquivo["type"])) {
        $error[1] = "O arquivo enviado não é um PDF.";
    }
    // Pega extensão do arquivo
    preg_match("/\.pdf$/i", $arquivo["name"], $ext);
    
    // Gera um nome único para o relatorio
    $nome_arquivo = $ano."_plano_trabalho_".$row_nome->nome."_".$semestre."_semestre" . $ext[0];

    // Caminho de onde ficará o arquivo
    $caminho_arquivo = "../plano_trabalho/relatorio_plano/" . $nome_arquivo;
        
    // Faz o upload da imagem para seu respectivo caminho
    move_uploaded_file($arquivo["tmp_name"], $caminho_arquivo);

    //salvando no bd
    $sql = "INSERT INTO plano_trabalho (arquivo, ano, semestre, id_professor)
            VALUES ('{$nome_arquivo}', '{$ano}', '{$semestre}', '{$id_professor}')";
    $res = $conexao->query($sql);

    if($res == true){
        echo "<script>alert('Enviado com sucesso!');</script>";
        echo "<script>location.href='?page=';</script>";
    }

    else{
        echo "<script>alert('Não foi possível enviar!');</script>";
        echo "<script>location.href='?page=';</script>";
    }
?>