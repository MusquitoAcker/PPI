<?php 
    session_start();
    if (empty($_SESSION)) {
        header('Location: ../index.php');
        exit();
    }

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nexum</title>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">

    <link rel="stylesheet" href="../assets/imagens/if.png">
    <link rel="stylesheet" href="../assets/linha_branca_cima.css">
    <link rel="stylesheet" href="../assets/plano.css">
    
</head>
<body>
    <div class="linha_branca_cima">
        <img class='logo_if' src="../assets/imagens/if.png" alt="Logo IF">
        <a class="titulo_nexum" href="?page=principal">Nexum</a>
        <?php 
            
        ?>

        <div>

        <div class="expansao" onclick="toggleMenu()">
            <i class="bi bi-list"></i>
        </div>

        <div class="menu_lateral">
            <ul>
            <li class="item_menu" id="item_menu">
                <?php 
                   
                    if($_SESSION["categoria"]==1){
                        echo "<a href=\"../gerenciar_usuario\">Gerenciar Usuarios</a>";
                    }
                    if(($_SESSION["categoria"]==1) || ($_SESSION["categoria"] == 2)){
                        echo "<a href=\"../gerenciar_disciplina\">Gerenciar Disciplinas</a>";
                        echo "<a href=\"../gerenciar_parecer\">Pareceres</a>";
                    }
                    echo "<a href=\"../curso_turma\">Cursos e Turmas</a>";
                    echo "<a href=\"../gerenciar_data\">Eventos</a>";
                    echo "<a href=\"../relatorio_atividade\">Relatórios de Atividades</a>";
                    echo "<a href=\"../plano_trabalho\">Plano de Trabalho</a>";
                    echo "<a class='botao_alterar_senha' href=\"../alterar_senha.php\">Alterar Senha</a>";
                    echo "<a class='botao_sair' href=\"?page=logout\">Sair</a>";
                ?>
                </div>
            </li>
            </ul>
        </div>

        <script>
            // Função para alternar a visibilidade do menu
            function toggleMenu() {
            const menuLateral = document.querySelector('.menu_lateral');
            const content = document.querySelector('.content');
            menuLateral.classList.toggle('expandido');
            content.classList.toggle('expandido');
            }
        </script>

        </div>
    </div>






    <div>
        <?php 
            include "../config.php";
            switch (@$_REQUEST["page"]){
                
                case 'enviar':
                    include("./form_enviar.php");
                    break;

                case 'salvar':
                    include("./salvar.php");
                    break;
                
                case 'logout':
                    header('Location: ../logout.php');
                    exit();
                    break;
                
                case 'principal':
                    header('Location: ../pagina_principal.php');
                    exit();
                    break;

                default:
                    if($_SESSION["categoria"] == 3){
                        echo "<a class='botao_enviar_plano' href=\"?page=enviar\">Enviar Plano</a>";
                    }
                    echo "<div class='titulo_principal'>Plano de Trabalho</div>";
                    include("listar.php");
                    break;
            }
        ?>

    </div>
</body>
</html>
