<?php 
            $sql = "SELECT * FROM datas
                    ORDER BY data";
            $res = $conexao->query($sql);
            $qtd = $res->num_rows;


            if ($qtd > 0) {

                while ($row = $res->fetch_object()){

                    echo "<div class='divisao_evento'>";
                        $date1 = DateTime::createFromFormat('Y-m-d', $row->data);
                        echo "Data: ";
                        echo $date1->format('d/m/Y') . "<br>" . $row->nome . "  ";

                        echo "<br> <br>";
                        if($_SESSION["id_usuario"] == $row->id_usuario){
                            echo "<button class='botao_editar_evento' onclick=\"location.href='?page=editar&id_data=" . $row->id_data . "';\">Editar</button>";
                            echo "<button class='botao_excluir_evento' onclick=\"if(confirm('Tem certeza que deseja excluir?')){location.href='?page=salvar&acao=excluir&id_data=".$row->id_data."';}else{false;}\"'>Excluir</button>";
                        }
                        else{
                            echo "<br><br>";
                        }
                        
        
                    echo "</div>";
                }
            }
            else{
                echo "Não há eventos registrados no sistema";
            }
        ?>