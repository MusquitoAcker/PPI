<div class='titulo_cadastrar_aluno'>Cadastrar Aluno</div>
<?php
    #consulta a tabela turma
    $sql_turma = "SELECT id_turma, numero FROM turma";

    $res_turma = $conexao->query($sql_turma);
    $qtd_turma = $res_turma->num_rows;

?>

<div class="container_cadastrar_aluno">
    <form enctype="multipart/form-data" action="?page=salvar_aluno&acao=cadastrar&idturma=<?php echo $_REQUEST["idturma"]; ?>" method="POST">
        <div>
        <br> 
            <label>Nome</label><br> 
            <input type="text" name="nome" required> <br> <br> 
        </div>
        <div> 
            <label>Data de Nascimento</label> <br> 
            <input type="date" name="data_nascimento" required> <br> <br> 
        </div>
        <div>
            <label>Número da Matrícula</label><br> 
            <input type="number" name="numero_matricula" required><br> <br> 
        </div>
        <div>
            <label>E-mail Institucional</label> <br> 
            <input type="e-mail" name="email"> <br>  <br> 
        </div>
        <div>
            <label>Cidade</label> <br> 
            <input type="text" name="cidade"> <br> <br> 
        </div>
        <div>
            <label>Unidade Federativa</label> <br> 
            <input type="text" name="uf"> <br> <br> 
        </div>
        <div>
            <label>Reprovações</label> <br> 
            <input type="number" name="quant_repro"> <br> <br> 
        </div>
        <div>
            <label>Moradia</label> <br> 
            <input type="text" name="moradia"> <br>  <br> 
        </div>
        <div>
            <label>Turma</label><br> 
            <select name="turma">
                <?php
                        if($qtd_turma>0){
                            while($row_turma = $res_turma->fetch_object()){
                                if($row_turma->id_turma == $_REQUEST["idturma"] ){
                                    echo "<option value=\"". $row_turma->id_turma."\"selected>". $row_turma->numero ."</option>";
                                }
                                else{
                                    echo "<option value=\"". $row_turma->id_turma."\">". $row_turma->numero ."</option>";
                                }
                            }
                        }  
                ?>
            </select>
        </div>

        <div>
        <br> 
            <label for="foto">Foto do Aluno</label> <br> 
            <input type="file" name="foto_aluno"> <br> <br> 
        </div>
        <div>
            <button class='botao_cadastrar_aluno' type="submit">Cadastrar</button> <br> <br> 
        </div>
    </form>

</div>