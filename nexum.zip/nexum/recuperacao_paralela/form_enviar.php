<div class="listar_recuperacao_container">
    
<h2>Relatório de Recuperação Paralela</h2>
<form enctype="multipart/form-data" action="?page=salvar_recup_para&idturma=<?php echo $_REQUEST["idturma"]?>&iddisciplina=<?php echo $_REQUEST["iddisciplina"]?>&nomedisciplina=<?php echo $_REQUEST["nomedisciplina"]?>&numeroturma=<?php echo $_REQUEST["numeroturma"]?>" method="POST">
    <div>
        <label class='parte_texto'>Relatório de Recuperação Paralela</label>   <br>
        <input type='file' name="rel_recup_para" required>  
        <br> <br>
    </div>
    <div>
        <label class='parte_texto'>Semestre</label>  <br>
        <select name="semestre">  <br>
            <option value="primeiro">1º Semestre</option>
            <option value="segundo">2º Semestre</option>
        </select>
        <br> <br>
    </div>

    <?php 
        echo "<button class='botao_verde' onclick=\"return confirm('Tem certeza que deseja enviar?')\">Enviar</button>";
    ?>
     <br>  <br>
</form>

</div>